import * as THREE from 'three';

const $ = s => document.querySelector(s);
const gameView = $('#gameView');
const state = {name:localStorage.getItem('gistcity_name')||'New GistCitizen', vibe:localStorage.getItem('gistcity_vibe')||'Everyday', skin:localStorage.getItem('gistcity_skin')||'#945d3d', outfit:localStorage.getItem('gistcity_outfit')||'#a5ff38', cash:Number(localStorage.getItem('gistcity_cash')||5000), cameraMode:0, moving:false, activityDone:false};
let scene,camera,renderer,clock,player,playerParts={},targetYaw=0,moveSpeed=4.5,spot,toastTimer;
const keys = new Set();
const buildings=[];
const V = (x,y,z)=>new THREE.Vector3(x,y,z);
function mat(color,roughness=.85){return new THREE.MeshStandardMaterial({color,roughness});}
function box(parent,name,w,h,d,material,x,y,z){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);mesh.name=name;mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;}
function cylinder(parent,r1,r2,h,material,x,y,z,segments=12){const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,segments),material);mesh.position.set(x,y,z);mesh.castShadow=true;parent.add(mesh);return mesh;}
function buildCity(){
  scene=new THREE.Scene(); scene.background=new THREE.Color('#9cc7c5'); scene.fog=new THREE.Fog('#9cc7c5',32,100);
  camera=new THREE.PerspectiveCamera(55,innerWidth/innerHeight,.1,180);
  renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,1.8));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;gameView.appendChild(renderer.domElement);
  clock=new THREE.Clock();scene.add(new THREE.HemisphereLight('#e5fff0','#384b37',2.0));const sun=new THREE.DirectionalLight('#fff1d5',3.0);sun.position.set(-18,30,15);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-35;sun.shadow.camera.right=35;sun.shadow.camera.top=35;sun.shadow.camera.bottom=-35;scene.add(sun);
  const ground= new THREE.Mesh(new THREE.PlaneGeometry(180,180),mat('#70866a'));ground.rotation.x=-Math.PI/2;ground.position.y=-.04;ground.receiveShadow=true;scene.add(ground);
  // Roads, pavements, road markings
  box(scene,'main-road',13,.08,100,mat('#343b39'),0,.01,0);box(scene,'cross-road',100,.08,11,mat('#343b39'),0,.02,-3);
  const lineMat=mat('#d5cda0');for(let z=-45;z<48;z+=5)box(scene,'road-line',.13,.025,2.1,lineMat,0,.07,z);
  for(let x=-44;x<=44;x+=8){box(scene,'pavement',2,.16,100,mat('#b6b6a3'),x,.06,0);}
  // Curated low-rise Nigerian neighbourhood blocks
  const palette=['#d5a06d','#c7c5a8','#d47e58','#91a99a','#d6c6a0','#ad8e77','#8fa5a2'];
  for(let side of [-1,1]) for(let row=0;row<5;row++) for(let col=0;col<4;col++){
    const x=side*(12+col*8.1), z=-35+row*17+(col%2)*2.1;
    if(Math.abs(z)<8&&col===0)continue;
    const w=5.4+((row+col)%2)*1.2,d=6.2+((row*2+col)%3),h=3.4+((row+col*2)%4)*1.45;
    const group=new THREE.Group();group.position.set(x,0,z);scene.add(group);
    box(group,'building',w,h,d,mat(palette[(row+col*2+(side===1?1:0))%palette.length]),0,h/2,0);
    box(group,'roof',w+.15,.22,d+.15,mat('#5a5b50'),0,h+.1,0);
    // Windows on the street-facing wall
    const winMat=mat('#3d5c5a',.4);const front=side===-1?1:-1;
    for(let yy=1;yy<h-0.2;yy+=1.45)for(let xx=-w/2+.8;xx<w/2-.3;xx+=1.35){box(group,'window',.62,.72,.06,winMat,xx,yy,front*(d/2+.035));}
    if(row%2===0){box(group,'door',.85,1.6,.08,mat('#604533'),w*.2,.8,front*(d/2+.06));}
    // small balcony/roof tank on selected buildings
    if((row+col)%3===0){cylinder(group,.4,.4,.7,mat('#68736b'),-w*.2,h+.55,0,10);}
    buildings.push({x,z,w,d});
  }
  // Palms and street furniture
  for(const [x,z] of [[-8,-9],[8,-15],[-8,13],[8,21],[-21,5],[21,-5],[-34,-18],[34,18]]){
    cylinder(scene,.19,.28,2.6,mat('#77563b'),x,1.3,z,8);
    for(let i=0;i<6;i++){const leaf=box(scene,'palm-leaf',.25,.12,2.4,mat('#3d794b'),x,2.55,z);leaf.rotation.y=i*Math.PI/3;leaf.rotation.x=-.25;}
  }
  // roadside kiosk / activity point
  const kiosk=new THREE.Group();kiosk.position.set(5,0,-8);scene.add(kiosk);box(kiosk,'kiosk',2.7,2.1,2.1,mat('#e0a84b'),0,1.05,0);box(kiosk,'kiosk-awning',3,.22,2.5,mat('#a5ff38'),0,2.22,0);box(kiosk,'kiosk-window',1.2,.75,.06,mat('#39564d'),0,1.4,1.08);box(kiosk,'kiosk-counter',2.9,.15,.5,mat('#694d32'),0,.9,1.2);
  // activity marker
  spot=new THREE.Group();spot.position.set(5,0,-12);scene.add(spot);const ring=new THREE.Mesh(new THREE.TorusGeometry(1.05,.07,8,32),mat('#a5ff38'));ring.rotation.x=Math.PI/2;ring.position.y=.12;spot.add(ring);const beam=new THREE.Mesh(new THREE.CylinderGeometry(.02,.65,2.3,24,1,true),new THREE.MeshBasicMaterial({color:'#a5ff38',transparent:true,opacity:.13,side:THREE.DoubleSide}));beam.position.y=1.25;spot.add(beam);const gem=new THREE.Mesh(new THREE.OctahedronGeometry(.35),mat('#caff83',.3));gem.position.y=1.8;spot.add(gem);spot.userData.gem=gem;
  makePlayer();
}
function makePlayer(){
  if(player)scene.remove(player);player=new THREE.Group();player.position.set(0,0,7);scene.add(player);
  const skin=mat(state.skin),shirt=mat(state.outfit),pants=mat(state.vibe==='Corporate'?'#252c2c':state.vibe==='Luxury'?'#27272a':'#27323a'),shoe=mat('#181a18'),hair=mat('#201914');
  // Stylized low-poly avatar assembled from 3D parts
  const torso=box(player,'torso',.78,.95,.4,shirt,0,1.48,0);playerParts.torso=torso;
  const head=cylinder(player,.29,.31,.55,skin,0,2.28,0,12);head.rotation.z=Math.PI;playerParts.head=head;
  const hairCap=cylinder(player,.31,.3,.18,hair,0,2.55,0,12);hairCap.position.y=2.52;
  const armL=box(player,'left-arm',.23,.78,.25,skin,-.54,1.48,0),armR=box(player,'right-arm',.23,.78,.25,skin,.54,1.48,0);playerParts.armL=armL;playerParts.armR=armR;
  const legL=box(player,'left-leg',.29,.72,.32,pants,-.22,.66,0),legR=box(player,'right-leg',.29,.72,.32,pants,.22,.66,0);playerParts.legL=legL;playerParts.legR=legR;
  box(player,'left-shoe',.34,.18,.48,shoe,-.22,.18,.07);box(player,'right-shoe',.34,.18,.48,shoe,.22,.18,.07);
  // Simple face details
  const eyeMat=mat('#171713');for(const x of [-.105,.105])box(player,'eye',.045,.045,.025,eyeMat,x,2.31,.29);
  const shadow=new THREE.Mesh(new THREE.CircleGeometry(.55,24),new THREE.MeshBasicMaterial({color:'#152017',transparent:true,opacity:.25}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.025;player.add(shadow);
  updateLabels();
}
function updateLabels(){$('#playerLabel').textContent=state.name;$('#vibeLabel').textContent=state.vibe.toUpperCase()+' VIBE';$('#cash').textContent='₦'+state.cash.toLocaleString('en-NG');$('#nameInput').value=state.name;document.querySelectorAll('[data-vibe]').forEach(b=>b.classList.toggle('selected',b.dataset.vibe===state.vibe));}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2800);}
function openPanel(id){$('#stylePanel').classList.add('hidden');$('#mapPanel').classList.add('hidden');$('#'+id).classList.remove('hidden');}
function closePanels(){$$('.panel').forEach(p=>p.classList.add('hidden'));}
function $$(s){return document.querySelectorAll(s)}
function persist(){for(const k of ['name','vibe','skin','outfit','cash'])localStorage.setItem('gistcity_'+k,state[k]);}
function applyStyle(){const n=$('#nameInput').value.trim();if(n)state.name=n;persist();makePlayer();updateLabels();closePanels();toast('Fresh look saved. Step back into the city!');}
function tryInteract(){const dist=player.position.distanceTo(spot.position);if(dist<3.3){if(!state.activityDone){state.cash+=750;state.activityDone=true;persist();updateLabels();$('#missionTitle').textContent='Neighbourhood discovered';$('#missionText').textContent='You found the local kiosk and earned ₦750. Keep exploring!';toast('Activity complete! You earned ₦750 💚');}else toast('You have already checked out this spot. Explore further!');}else{toast('Get closer to the glowing green marker to interact.');}}
function movePlayer(dt){let forward=(keys.has('w')||keys.has('arrowup')||keys.has('forward'))?1:0;let back=(keys.has('s')||keys.has('arrowdown')||keys.has('back'))?1:0;let left=(keys.has('a')||keys.has('arrowleft')||keys.has('left'))?1:0;let right=(keys.has('d')||keys.has('arrowright')||keys.has('right'))?1:0;const x=right-left,z=back-forward;const moving=Math.abs(x)+Math.abs(z)>0;
 if(moving){const len=Math.hypot(x,z)||1;const dir=V(x/len,0,z/len);player.position.addScaledVector(dir,moveSpeed*dt);player.position.x=THREE.MathUtils.clamp(player.position.x,-43,43);player.position.z=THREE.MathUtils.clamp(player.position.z,-46,46);targetYaw=Math.atan2(dir.x,dir.z);player.rotation.y=THREE.MathUtils.lerp(player.rotation.y,targetYaw,Math.min(1,dt*12));const t=clock.elapsedTime*10;playerParts.legL.rotation.x=Math.sin(t)*.55;playerParts.legR.rotation.x=-Math.sin(t)*.55;playerParts.armL.rotation.x=-Math.sin(t)*.38;playerParts.armR.rotation.x=Math.sin(t)*.38;}else{playerParts.legL.rotation.x=THREE.MathUtils.lerp(playerParts.legL.rotation.x,0,dt*8);playerParts.legR.rotation.x=THREE.MathUtils.lerp(playerParts.legR.rotation.x,0,dt*8);playerParts.armL.rotation.x=THREE.MathUtils.lerp(playerParts.armL.rotation.x,0,dt*8);playerParts.armR.rotation.x=THREE.MathUtils.lerp(playerParts.armR.rotation.x,0,dt*8);}
 if(player.position.distanceTo(spot.position)<3.3){$('#missionTitle').textContent='Activity nearby';$('#missionText').textContent='Press SPACE or tap the screen to check it out.';}else if(!state.activityDone){$('#missionTitle').textContent='Explore your neighbourhood';$('#missionText').textContent='Walk to the glowing spot to discover an activity.';}
}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05);movePlayer(dt);spot.position.y=Math.sin(clock.elapsedTime*2)*.08;spot.userData.gem.rotation.y+=dt*.9;spot.userData.gem.rotation.x+=dt*.35;
 const distance=state.cameraMode===0?new THREE.Vector3(0,5.3,9.3):new THREE.Vector3(0,8.5,13.5);const desired=player.position.clone().add(distance);camera.position.lerp(desired,Math.min(1,dt*4));camera.lookAt(player.position.clone().add(V(0,1.2,0)));renderer.render(scene,camera);}
function init(){buildCity();camera.position.set(0,6,16);camera.lookAt(0,0,0);updateLabels();animate();setTimeout(()=>$('#loading').classList.add('done'),850);setTimeout(()=>$('#loading').style.display='none',1500);}
window.addEventListener('resize',()=>{if(!camera||!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
window.addEventListener('keydown',e=>{const key=e.key.toLowerCase();if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(key))e.preventDefault();keys.add(key);if(key===' '&&!e.repeat)tryInteract();if(key==='escape')closePanels();});window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));window.addEventListener('blur',()=>keys.clear());
$$('[data-move]').forEach(btn=>{const key=btn.dataset.move;const down=e=>{e.preventDefault();keys.add(key);};const up=e=>{e.preventDefault();keys.delete(key);};btn.addEventListener('pointerdown',down);btn.addEventListener('pointerup',up);btn.addEventListener('pointercancel',up);btn.addEventListener('pointerleave',up);});
$('#gameView').addEventListener('pointerdown',e=>{if(e.target===renderer.domElement&&e.pointerType==='touch'&&e.clientX>innerWidth*.4){tryInteract();}});
$('#openStyle').addEventListener('click',()=>openPanel('stylePanel'));$('#saveStyle').addEventListener('click',applyStyle);$('#cameraBtn').addEventListener('click',()=>{state.cameraMode=(state.cameraMode+1)%2;toast(state.cameraMode?'Wide camera view':'Close camera view');});$('#mapBtn').addEventListener('click',()=>openPanel('mapPanel'));$$('[data-close]').forEach(b=>b.addEventListener('click',closePanels));$('#renameBtn').addEventListener('click',()=>openPanel('stylePanel'));$('#plusCash').addEventListener('click',()=>{state.cash+=250;persist();updateLabels();toast('Demo bonus added: ₦250');});$$('[data-vibe]').forEach(b=>b.addEventListener('click',()=>{state.vibe=b.dataset.vibe;document.querySelectorAll('[data-vibe]').forEach(x=>x.classList.toggle('selected',x===b));}));$$('[data-skin]').forEach(b=>b.addEventListener('click',()=>{state.skin=b.dataset.skin;makePlayer();}));$$('[data-outfit]').forEach(b=>b.addEventListener('click',()=>{state.outfit=b.dataset.outfit;makePlayer();}));
init();
